#include <iostream>
using namespace std;

int main(){
    for (int i = 0; i <= 6; i++){
        cout << 2 * i + 1 << ", ";
    }
    cout << endl;

    for (int i = 0; i <= 5; i++){
        cout << 3 * i + 2 << ", ";
    }
    cout << endl;

    for (int i = 0; i <= 6; i++){
        cout << 30 - 10 * i << ", ";
    }
    cout << endl;

    for (int i = 0; i <= 5; i++){
        cout << 8 * i + 15 << ", ";
    }
    cout << endl;

    return 0;
}